#
# Copyright 2015 by Justin MacCallum, Alberto Perez, and Ken Dill
# All rights reserved
#

import logging

logger = logging.getLogger("meld")
logger.addHandler(logging.NullHandler())

__version__ = "0.4.14"
